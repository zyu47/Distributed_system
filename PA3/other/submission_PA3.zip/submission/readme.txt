This is the submission for PA3 of CS555.

The src folder contains every source code required for the program to be functional. There are 9 packages (from q1 to q9), each corresponding to the question from the assianment. The compilation of the source codes require hadoop jar files. I did it in eclipse by including the necessary libaries.

For q9, there is a python file required for visualization of the analitical results.
